#!/bin/bash
#SBATCH --time=16:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=128
## #SBATCH --mail-type=FAIL,BEGIN,END
## #SBATCH --mail-user=mash@lanl.gov
#SBATCH --job-name=ML_train
## #SBATCH --error myjob_%j.err
#SBATCH -A xd
### SBATCH -A xd
#SBATCH --qos=standard
#SBATCH --reservation=debug
#SBATCH --partition=standard

module load intel-mkl/2021.2.0
module load intel/19.1.3
module load intel-ccl/2021.2.0
module load intel-ipp/2021.2.0
module load intel-mpi/2021.5.1
ulimit -s unlimited

export OMP_STACKSIZE=1000000

rm *nn* slurm* myjob*
/users/mash/calibrationmash/nn_calib_icc_new -in TiV.input  > train.output
